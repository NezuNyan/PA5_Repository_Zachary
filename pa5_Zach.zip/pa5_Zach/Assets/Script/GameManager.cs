﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour
{

    public static GameManager thismanager;

    public Text txtscore;

    private int score;
    int totalcoins;
    // Start is called before the first frame update
    void Start()
    {
        thismanager = this;
        foreach (GameObject coin in GameObject.FindGameObjectsWithTag("Coins"))
        {
            totalcoins += 1;
        }
    }

    // Update is called once per frame
    void Update()
    {
        print(score);
        txtscore.text = "Coins: " + score;
        
        if (score >= totalcoins)
        {
            gamewin();
        }
    }
    public void increasescore()
    {
        score += 1;
    }
    public void gamelose()
    {
        SceneManager.LoadScene("Lose");
    }
    public void gamewin()
    {

        SceneManager.LoadScene("Win");
        
    }
}
